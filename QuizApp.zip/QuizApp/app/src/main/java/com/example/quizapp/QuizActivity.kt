package com.example.quizapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private lateinit var questionText: TextView
    private lateinit var scoreText: TextView
    private lateinit var optionButtons: List<Button>

    private var currentQuestionIndex = 0
    private var score = 0

    private val questions = listOf(
        Question("Was ist die Hauptstadt von Deutschland?", listOf("Berlin", "München", "Hamburg"), 0),
        Question("Wie viele Planeten hat das Sonnensystem?", listOf("7", "8", "9"), 1),
        Question("Welches Jahr hatte 366 Tage?", listOf("2023", "2020", "2021"), 1)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        questionText = findViewById(R.id.questionText)
        scoreText = findViewById(R.id.scoreText)

        optionButtons = listOf(
            findViewById(R.id.option1),
            findViewById(R.id.option2),
            findViewById(R.id.option3)
        )

        loadQuestion()
    }

    private fun loadQuestion() {
        if (currentQuestionIndex >= questions.size) {
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("score", score)
            intent.putExtra("total", questions.size)
            startActivity(intent)
            finish()
            return
        }

        val q = questions[currentQuestionIndex]
        questionText.text = q.text
        scoreText.text = "Punkte: $score"

        for (i in optionButtons.indices) {
            optionButtons[i].text = q.options[i]
            optionButtons[i].setBackgroundColor(Color.LTGRAY)
            optionButtons[i].setOnClickListener {
                checkAnswer(i)
            }
        }
    }

    private fun checkAnswer(selectedIndex: Int) {
        val correct = questions[currentQuestionIndex].correctAnswerIndex

        if (selectedIndex == correct) {
            optionButtons[selectedIndex].setBackgroundColor(Color.GREEN)
            score++
        } else {
            optionButtons[selectedIndex].setBackgroundColor(Color.RED)
            optionButtons[correct].setBackgroundColor(Color.GREEN)
        }

        Handler().postDelayed({
            currentQuestionIndex++
            loadQuestion()
        }, 1000)
    }
}
